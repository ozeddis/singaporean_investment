<!DOCTYPE>
<html>
<style type="text/css">

    <header>

<body style="background-color: #f1f1f1;">

<tagname style="property:value;"><a href="http://www.herbalworld.com ">Herbal World</a></tagname>
<center>

<meta charset="UTF-8"><h1 style="background-color: #f1f1f1" style="font-color:steelblue; ">
WORLD FAMOUS<sup>®</sup></h1></center>
<style>

input[type=text],
      input[type=password] {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
}

button {
      background-color: #48d1cc;
      color: white; padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
}

.cancelbtn {
      width: auto;
      padding: 10px 18px;
      background-color: #4682b4;
      }

.imgcontainer {
      text-align: center;
      margin: 24px 0 12px 0;
      position: relative;
}

img.avatar {
      width: 40%;
      border-radius: 50%;
}

.container {
      padding: 16px;
}

span.psw {
      float: right;
      padding-top: 16px;
}

.modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0; top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgb(0,0,0);
      background-color: rgba(0,0,0,0.4);
      padding-top: 60px;
}

.modal-content {
      background-color: #fefefe;
      margin: 5% auto 15% auto;
      border: 1px solid #888;
      width: 80%;
}

/* The Close Button (x) */

.close {
      position: absolute;
      left: 23px; top: 1;
      color: #000;
      font-size: 35px;
      font-weight: bold;
}

.close:hover, .close:focus {
      color: red;
      cursor: pointer;
}

/* Add Zoom Animation */

.animate {
      -webkit-animation: animatezoom 0.6s;
      animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
      from {-webkit-transform: scale(0)
}
to {
      -webkit-transform: scale(1)
}
 }

@keyframes animatezoom {
from {transform: scale(0)} to {transform: scale(1)
} }

@media screen and(max-width: 300px){ span.psw {

} .cancelbtn {

} }

</style>

</header><body>

<h2> Admin login</h2>
<button onclick="document. getElementById('id01')

.style.display='block' " style="width:auto;">Login </button>

<div id="id01" class="modal" style="display: block;">

<form class="modal-content animate" action="action_page.php"> <div class="imgcontainer"> <span onclick="document .getElemebyid('id01')
.style.display='none'" class="close" title=" close modal&amp;
times;</span>

<img src=".png"t">
</span></div>


<div class="container">
<label><b>Username</b></label><b>
<input type="text" placeholder="Username" name="uname" required="">
<form="action:username"></form="action:username"></b></div><b>


<div class="container">
<label><b>Password</b></label>
<input type="password" placeholder"enter="" password"="" name="pws" required="">
<form="action:password">
<button type="submit" style="font-family:san seriff">Login</button>
<input type="checkbox" checked="checked">First visit
<input type="checkbox" checked="checked">Remenber me
</form="action:password"></div>


<div class="container" style="background-color: #f1f1f1">

<button type="button" ('id01').style.="" display="none" "="" class="cancelbtn" oneclick="document.getelementbyid">
Close</button>
<span class="psw">Forgot
<a href="#*">Password?
<div class="col-sm-6">
					<ul class="social-network">
						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
</a></span>
</div>
<script>

var modal = getelementbyid
('id01')
window.click = function(event) {
if (event.target ==modal) {modal.style.display = "none";
             }
   }
</script>

    <meta charset="UTF-8">




<h2 style="background-color: #f1f1f1"> DR OZEDDI OZEDDI'S HERBAL HOME</h2>

<p style="background-color: #f1f1f1"> <a href="https://www.ozeddisherbalhome.com/xhml/w3schools.com/html/"><button style="font-family:San-seriff">Home Of Herbal/Traditional medicine</button></a></p><a href="https://www.herbalworld.com/xhml/w3schools.com/html/">
</a><a href="http://www.ozeddisherbalhome.com"><a class="none" button="" style=" font-family:consolas">
<li>Home</li>
</a></a>
<style>
ul {
    list-style-type; none;
    margin: 5px;
    padding: 0;
    width:200px;
    background-color: #f1f1f1;
}
li a {
     display: block;
     color: #000;
     padding: 8px 0 8px 16px;
     text-decoration: none;
}
li a.active not(active){
    background-color:  #f1f1f1;
    color: white;
}
li a.hover:active {
    background-color: #f1f1f1;
    color:white
}
</style>
<li><a class="active" href="#Content">Content</a>
</li>
<li><a href="#contact">Contact</a>
</li>
<li><a href="#about">About</a>
</li>


<p style="font-size:40px;">
            <style="font-family:consolas"><b><em>Home Of Herbal Medicine <sub><i>(ogwu mgborogwu na mpkakwukwo)</i></sub></em></b></style="font-family:consolas"></p>

      <hr>

      	<div style="font-family:consolas"><b>We Treat The Following</b>
             <p>Physical or Spiritual</p>
              </div>
     		 <div>
      	<ui>Typhoid</ui>

            <h2 style="font-size:50px; "><strong>We treat but God heals</strong></h2>
                <p style="color:steelblack"> <a href="html_images.asp"><button style="font-family:courier">About us</button></a></p>

<hr>

<p style="color:deepgreen; style=" font-size:50p%;="">COMING SOON!!!...</p>
<style>
a:link {
    color: black;
    background-color: transparent;
    text-decoration: none;
}

a:visited {
    color: pink;
    background-color: transparent;
    text-decoration: none;
}

a:hover {
    color: red;
    background-color: transparent;
    text-decoration: underline;
}

a:active {
    color: yellow;
    background-color: transparent;
    text-decoration: underline;
}
</style>
</html>